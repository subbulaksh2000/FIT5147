library(shiny)
library(ggplot2)
library(dplyr)
library(leaflet)

# Load data
dataset_1 <- read.csv("Accident_Data.csv")

# Define UI - using fixed page command we use it for creating the UI interface
ui <- fixedPage(
  titlePanel("Accident Data Visualization"),
  
  fluidRow(
    column(width = 6,
           plotOutput("vis1", width = "110%", height = "600px"),
           sliderInput("severity_slider", "Severity Rank", 
                       min = min(dataset_1$SEVERITY_RANK), 
                       max = max(dataset_1$SEVERITY_RANK),
                       value = c(min(dataset_1$SEVERITY_RANK), max(dataset_1$SEVERITY_RANK)),
                       step = 1),
           p("This is a stacked bar chart showing the number of accidents by light condition and speed zone. It will show the speed zone in different zone by no of accident. This stacked bar graph will show the distinguished using the light condition description given in the dataset. When we use the tooltip using the severity rank we can see the changes from the rank 1 to 3 how the speed zone by number of accident using light condition description")
    ),
    column(width = 6,
           plotOutput("vis2", width = "110%", height = "600px"),
           checkboxGroupInput("daynight_check", "Filter by Day/Night",
                              choices = unique(dataset_1$LIGHT_CONDITION_DESC),
                              selected = unique(dataset_1$LIGHT_CONDITION_DESC)),
           p("This is a line chart showing the number of accidents by hour for the top 4 speed zones. The line graph shows the number of accidents that can occur in each hour which are sorted in the top speed zone according to the accident given in the dataset.")
    )
  ),
  
  fluidRow(
    column(width = 12,
           leafletOutput("map", width = "100%", height = "600px"),
           p("This is a Leaflet map showing the location of accidents. Circle markers that shown in the map using the daynight value using the values such as day, night or dusk/dawn. Which will correspond to the certain values with the attribute in the dataset in the light condition description.")
    )
  )
)

# Define server logic
server <- function(input, output) {
  # Filtered data based on slider input and checkbox input for severity rank and light condition description
  filtered_data <- reactive({
    dataset_1 %>%
      filter(SEVERITY_RANK >= input$severity_slider[1] & SEVERITY_RANK <= input$severity_slider[2]) %>%
      filter(LIGHT_CONDITION_DESC %in% input$daynight_check)
  })
  
  # Visualization 1: Stacked bar chart - using the speed zone and Number of accident occurred by the Light Condition description
  output$vis1 <- renderPlot({
    ggplot(filtered_data(), aes(fill = LIGHT_CONDITION_DESC, x = SPEED_ZONE)) +
      geom_bar(position = "stack") +
      labs(x = "Speed Zone in Victoria", y = "Number of Accidents Occurred") +
      ggtitle("Accidents by Light Condition and Speed Zone") +
      theme_minimal()
  })
  
  # Visualization 2: Line chart - Accident by hour for top 4 speed zone
  output$vis2 <- renderPlot({
    top_speeding_zones <- filtered_data() %>%
      group_by(SPEED_ZONE) %>%
      summarize(total_accidents = n()) %>%
      arrange(desc(total_accidents)) %>%
      head(4) %>%
      pull(SPEED_ZONE)
    
    ggplot(filtered_data() %>% filter(SPEED_ZONE %in% top_speeding_zones), aes(x = ACCIDENT_TIME, color = SPEED_ZONE, group = SPEED_ZONE)) +
      geom_line(stat = "count") +
      labs(title = "Accidents by Hour for Top 4 Speed Zones",
           x = "Hour of Day", y = "Number of Accidents",
           color = "Speed Zone") +
      theme_minimal()
  })
  
  # Leaflet Map
  output$map <- renderLeaflet({
    light_condition_palette <- c("day" = "blue", "dusk/dawn" = "orange", "night" = "black")
    
    severity <- function(x) {
      max_val <- max(x)
      return(max_val - x + 1)
    }
    
    leaflet(filtered_data()) %>%
      addProviderTiles("OpenStreetMap.Mapnik") %>%
      addCircleMarkers(
        lng = ~LONGITUDE,
        lat = ~LATITUDE,
        color = ~LIGHT_CONDITION_DESC,
        radius = ~severity(SEVERITY_RANK) * 5,
        stroke = FALSE,
        fillOpacity = 0.8,
        label = ~paste("Date:", ACCIDENT_DATE, "<br>",
                       "Type:", ACCIDENT_TYPE_DESC, "<br>",
                       "Light:", LIGHT_CONDITION_DESC, "<br>",
                       "Road:", ROAD_GEOMETRY_DESC, "<br>",
                       "Speed Zone:", SPEED_ZONE)
      ) %>%
      addLegend(
        position = "bottomright",
        colors = light_condition_palette,
        labels = c("Day", "Dusk/Dawn", "Night"),
        title = "Light Condition"
      )
  })
}

# Run the application in R Shiny
shinyApp(ui = ui, server = server)

