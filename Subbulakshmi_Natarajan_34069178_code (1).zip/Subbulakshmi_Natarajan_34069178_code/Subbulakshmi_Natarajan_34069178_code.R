library(shiny)
library(shinydashboard)
library(ggplot2)
library(readxl)
library(dplyr)
library(plotly)
library(reshape2)
library(crosstalk)  # For linking plotly graphs
library(networkD3)

# Load data
anime <- read_excel("anime_cleaned data_score and pop.xlsx")
manga <- read_excel("manga_cleaned_score_pop.xlsx")

# Clean data
anime <- anime %>% filter(is.finite(Score) & is.finite(Popularity))
manga <- manga %>% filter(is.finite(Score) & is.finite(Popularity))

# UI with added styles
ui <- dashboardPage(
  dashboardHeader(title = "Anime and Manga Dashboard"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Bar Graphs", tabName = "barGraphs", icon = icon("chart-bar")),
      menuItem("Box Plots", tabName = "boxPlots", icon = icon("chart-bar")),
      menuItem("Anime Sankey Diagram", tabName = "animeSankeyDiagram", icon = icon("project-diagram")),
      menuItem("Manga Sankey Diagram", tabName = "mangaSankeyDiagram", icon = icon("project-diagram")),
      menuItem("Pie Charts", tabName = "pieCharts", icon = icon("chart-pie"))
    )
  ),
  dashboardBody(
    tags$head(
      tags$style(HTML("
        .skin-blue .main-header .navbar {
          background-color: #4E5D6C;
        }
        .skin-blue .main-header .logo {
          background-color: #37505C;
          color: #FFF;
        }
        .skin-blue .main-sidebar {
          background-color: #2F4050;
        }
        .box {
          border-top-color: #374850;
        }
        body {
          background-color: #D2D6DE;
          font-family: 'Arial', sans-serif;
        }
      "))
    ),
    tabItems(
      tabItem(tabName = "barGraphs",
              fluidRow(
                box(title = "Anime Type Distribution", status = "primary", solidHeader = TRUE, collapsible = TRUE,
                    checkboxGroupInput("selectedAnimeTypes", "Select Anime Types:", choices = unique(anime$type), selected = unique(anime$type)),
                    plotlyOutput("animeTypePlot"),
                    p("The bar chart shows how various forms of anime are spread based on their count. The x-axis displays several types of anime, such as movies, music, ONA, OVA, specials, and TV series, while the y-axis shows how many of each category exist. The blue bars show these numbers, with the height proportional to the number of anime of that category. TV series have the largest count, making them the most popular anime type. Movies and OVAs have high counts, suggesting their popularity. Special anime have a reasonable count, whereas ONAs are less common but still more prevalent than music-related anime, which has the lowest count.")
                ),
                box(title = "Manga Type Distribution", status = "primary", solidHeader = TRUE, collapsible = TRUE,
                    checkboxGroupInput("selectedMangaTypes", "Select Manga Types:", choices = unique(manga$type), selected = unique(manga$type)),
                    plotlyOutput("mangaTypePlot"),
                    p("The bar chart shows how various types of manga are distributed based on their count. The x-axis includes several sorts of manga, such as doujinshi, light novels, manga, manhua, manhwa, novels, and one-shots, while the y-axis displays how many of each type exist. The green bars show these counts, with the height proportional to the number of manga of that category. Manga has the highest count, making it the most popular manga genre by a wide margin. Light novels and manhwa have moderate counts, but doujinshi, manhua, novels, and one-shots have low counts.")
                )
              )
      ),
      tabItem(tabName = "boxPlots",
              fluidRow(
                box(title = "Score Comparison", status = "warning", solidHeader = TRUE, collapsible = TRUE,
                    sliderInput("scoreRange", "Score Range:", min = min(c(anime$Score, manga$Score)), max = max(c(anime$Score, manga$Score)), value = c(min(c(anime$Score, manga$Score)), max(c(anime$Score, manga$Score)))),
                    plotlyOutput("scoreBoxPlot"),
                    p("The graphic shows a 'Score Comparison' box plot within a web-based dashboard for analysing and visualising anime and manga data. This graphic contrasts the distribution of scores for anime and manga, which are represented by red and cyan boxes, respectively. The graphic shows numerous essential data for each medium, including the minimum, first quartile, median, third quartile, and maximum. Notably, the anime scores appear to be more diverse, with a cluster of outliers stretching to the higher end. In contrast, manga scores are more compactly distributed but still vary.")
                ),
                box(title = "Popularity Comparison", status = "warning", solidHeader = TRUE, collapsible = TRUE,
                    sliderInput("popularityRange", "Popularity Range:", min = min(c(anime$Popularity, manga$Popularity)), max = max(c(anime$Popularity, manga$Popularity)), value = c(min(c(anime$Popularity, manga$Popularity)), max(c(anime$Popularity, manga$Popularity)))),
                    plotlyOutput("popularityBoxPlot"),
                    p("The graphic shows a 'Popularity Comparison' box plot from a web-based dashboard used to analyse anime and manga data. This graph shows a visual comparison of popularity ratings for anime and manga, represented by red and cyan boxes, respectively. Lower numbers imply greater popularity. The anime popularity distribution, illustrated in red, has a tighter range and a lower median, indicating that anime titles are more consistently popular than manga. The figure has outliers above the top whisker, showing that certain anime titles are much less popular. In comparison, the manga box (shown in cyan) has a wider range and a higher median, indicating greater diversity in popularity.")
                )
              )),
      tabItem(tabName = "animeSankeyDiagram",
              fluidRow(
                box(title = "Sankey Diagram of Source to Type for Anime", width = 12, status = "primary", solidHeader = TRUE,
                    sankeyNetworkOutput("animeSankeyPlot", height = "600px"),
                    p("The image depicts a 'Sankey Diagram of Source to Type for Anime,' which is used to visualise the relationships between various sources of anime content and their adaptations into various anime formats such as TV shows, movies, OVAs, and specials. Each source and anime genre is colour-coded differently—manga is green and TV series is blue, for example—making it easy to distinguish across categories. The thickness of the lines connecting sources to types represents the volume of adaptations, with larger lines signifying more adaptations from a single source to a type.")
                )
              )),
      tabItem(tabName = "mangaSankeyDiagram",
              fluidRow(
                box(title = "Sankey Diagram of Demographics to Type for Manga", width = 12, status = "primary", solidHeader = TRUE,
                    sankeyNetworkOutput("mangaSankeyPlot", height = "600px"),
                    p("The thickness of the lines in the Sankey figure represents the volume of manga generated for each demographic group assigned to each manga type category. For example, a thicker line connecting 'Shounen' to manga' would imply a higher volume of Shounen manga than other categories. This visualisation tool efficiently depicts the target demographic distributions within the manga industry, as well as how distinct manga styles cater to different demographics, providing insights into market trends and content strategies.")
                )
              )),
      tabItem(tabName = "pieCharts",
              fluidRow(
                box(title = "Pie Chart for Manga Demographics", status = "primary", solidHeader = TRUE, collapsible = TRUE,
                    checkboxGroupInput("selectedMangaDemographics", "Select Manga Demographics:", choices = unique(manga$demographics), selected = unique(manga$demographics)),
                    plotOutput("mangaDemographicPieChart"),
                    p("On the left side, there is a pie chart captioned 'Pie Chart for Manga Demographics.' The chart is accompanied with a checkbox group where users can decide which demographics to display. The demographics chosen are Seinen, Shounen, Seinen/Shounen, Unknown, Shoujo, Josei, Kids, Kids/Shounen, Seinen/Shoujo, and Kids/Shoujo. The data shows that 'Unknown' is the largest demographic category, accounting for 48% of the Manga distribution. Other large categories include Seinen (19%), Shounen (16%), and Shoujo (14%), with the remaining demographics accounting for lower percentages.")
                ),
                box(title = "Pie Chart for Anime Demographics", status = "primary", solidHeader = TRUE, collapsible = TRUE,
                    checkboxGroupInput("selectedAnimeDemographics", "Select Anime Demographics:", choices = unique(anime$demographics), selected = unique(anime$demographics)),
                    plotOutput("animeDemographicPieChart"),
                    p("On the right side, there is a pie chart labelled 'Pie Chart for Anime Demographics,' along with a similar checkbox group for selecting demographics. The demographics chosen are Shounen, Unknown, Seinen, Shoujo, Josei, Kids, and Kids/Shounen. The figure shows that 'Unknown' is the most common demography, accounting for 68% of the Anime distribution. Other important sectors include Shounen (15%) and Seinen (8%), with minor contributions from other demographics.")
                )
              ))
    )
  )
)

# Server function to create Sankey diagram, pie charts, and other plots
server <- function(input, output) {
  shared_anime <- SharedData$new(anime)
  shared_manga <- SharedData$new(manga)
  
  output$animeTypePlot <- renderPlotly({
    filtered_anime <- shared_anime$data() %>% filter(type %in% input$selectedAnimeTypes)
    data <- filtered_anime %>% count(type)
    p <- ggplot(data, aes(x = type, y = n, fill = type)) +
      geom_bar(stat = "identity") +
      theme_minimal()
    ggplotly(p) %>% highlight("plotly_hover")
  })
  
  output$mangaTypePlot <- renderPlotly({
    filtered_manga <- shared_manga$data() %>% filter(type %in% input$selectedMangaTypes)
    data <- filtered_manga %>% count(type)
    p <- ggplot(data, aes(x = type, y = n, fill = type)) +
      geom_bar(stat = "identity") +
      theme_minimal()
    ggplotly(p) %>% highlight("plotly_hover")
  })
  
  output$scoreBoxPlot <- renderPlotly({
    filtered_anime <- shared_anime$data() %>% filter(Score >= input$scoreRange[1] & Score <= input$scoreRange[2])
    filtered_manga <- shared_manga$data() %>% filter(Score >= input$scoreRange[1] & Score <= input$scoreRange[2])
    data <- rbind(data.frame(Source = 'Anime', Value = filtered_anime$Score),
                  data.frame(Source = 'Manga', Value = filtered_manga$Score))
    p <- ggplot(data, aes(x = Source, y = Value, fill = Source)) + geom_boxplot() + theme_minimal()
    ggplotly(p) %>% highlight("plotly_hover")
  })
  
  output$popularityBoxPlot <- renderPlotly({
    filtered_anime <- shared_anime$data() %>% filter(Popularity >= input$popularityRange[1] & Popularity <= input$popularityRange[2])
    filtered_manga <- shared_manga$data() %>% filter(Popularity >= input$popularityRange[1] & Popularity <= input$popularityRange[2])
    data <- rbind(data.frame(Source = 'Anime', Popularity = filtered_anime$Popularity),
                  data.frame(Source = 'Manga', Popularity = filtered_manga$Popularity))
    p <- ggplot(data, aes(x = Source, y = Popularity, fill = Source)) + geom_boxplot() + theme_minimal()
    ggplotly(p) %>% highlight("plotly_hover")
  })
  
  # Sankey Diagram for Anime
  output$animeSankeyPlot <- renderSankeyNetwork({
    # Prepare data for Sankey diagram
    sankey_data <- anime %>%
      select(Source = source, Type = type) %>%
      group_by(Source, Type) %>%
      summarise(count = n(), .groups = 'drop')
    
    # Create nodes
    nodes <- data.frame(name = unique(c(sankey_data$Source, sankey_data$Type)))
    
    # Create links
    links <- sankey_data %>%
      mutate(
        sourceID = match(Source, nodes$name) - 1,
        targetID = match(Type, nodes$name) - 1
      ) %>%
      select(sourceID, targetID, count) %>%
      as.data.frame() # Ensure links is a plain data frame
    
    # Create the Sankey diagram
    sankeyNetwork(Links = links, Nodes = nodes, Source = "sourceID", Target = "targetID", Value = "count",
                  NodeID = "name", fontSize = 12, nodeWidth = 30)
  })
  
  # Sankey Diagram for Manga
  output$mangaSankeyPlot <- renderSankeyNetwork({
    # Prepare data for Sankey diagram
    sankey_data <- manga %>%
      select(Source = demographics, Type = type) %>%
      group_by(Source, Type) %>%
      summarise(count = n(), .groups = 'drop')
    
    # Create nodes
    nodes <- data.frame(name = unique(c(sankey_data$Source, sankey_data$Type)))
    
    # Create links
    links <- sankey_data %>%
      mutate(
        sourceID = match(Source, nodes$name) - 1,
        targetID = match(Type, nodes$name) - 1
      ) %>%
      select(sourceID, targetID, count) %>%
      as.data.frame() # Ensure links is a plain data frame
    
    # Create the Sankey diagram
    sankeyNetwork(Links = links, Nodes = nodes, Source = "sourceID", Target = "targetID", Value = "count",
                  NodeID = "name", fontSize = 12, nodeWidth = 30)
  })
  
  # Pie Charts
  output$mangaDemographicPieChart <- renderPlot({
    filtered_manga <- manga %>% filter(demographics %in% input$selectedMangaDemographics)
    
    manga_demographic_counts <- filtered_manga %>%
      group_by(demographics) %>%
      summarise(count = n())
    
    ggplot(manga_demographic_counts, aes(x = "", y = count, fill = demographics)) +
      geom_bar(stat = "identity", width = 1) +
      coord_polar("y") +
      labs(title = "Demographic Distribution of Manga", y = "Count") +
      theme_void() +
      theme(legend.position = "right", plot.title = element_text(hjust = 0.5)) +
      geom_text(aes(label = paste0(round(count / sum(count) * 100), "%")), position = position_stack(vjust = 0.5))
  })
  
  output$animeDemographicPieChart <- renderPlot({
    filtered_anime <- anime %>% filter(demographics %in% input$selectedAnimeDemographics)
    
    anime_demographic_counts <- filtered_anime %>%
      group_by(demographics) %>%
      summarise(count = n())
    
    ggplot(anime_demographic_counts, aes(x = "", y = count, fill = demographics)) +
      geom_bar(stat = "identity", width = 1) +
      coord_polar("y") +
      labs(title = "Demographic Distribution of Anime", y = "Count") +
      theme_void() +
      theme(legend.position = "right", plot.title = element_text(hjust = 0.5)) +
      geom_text(aes(label = paste0(round(count / sum(count) * 100), "%")), position = position_stack(vjust = 0.5))
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
